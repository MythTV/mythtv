/* This file was automatically generated. */
#define VERSION "1.3 (2003-10-17)"
